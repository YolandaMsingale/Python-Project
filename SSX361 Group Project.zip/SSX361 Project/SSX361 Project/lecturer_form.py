
import tkinter as tk
from tkinter import messagebox, Listbox, Scrollbar, ttk
import lecturer_create as lc
import lecturer_insert as li
import lecturer_update as lu
import lecturer_read as lr
import lecturer_delete as ld

def animate_label(label, color1, color2, delay):
    """Animate label color alternation."""
    label.config(foreground=color1)
    label.after(delay, lambda: animate_label(label, color2, color1, delay))
class LecturerForm(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Lecturer Form")
        self.geometry("700x500")
        self.config(bg="#ADD8E6")


        welcome_label = ttk.Label(self, text="Lecturer Details", font=("Arial", 24, "bold"), foreground="white",
                                  background="#87CEEB")
        welcome_label.pack()
        animate_label(welcome_label, "blue", "white", 1000)

#Define StringVar variables for input fields
        self.name_var = tk.StringVar()
        self.surname_var = tk.StringVar()
        self.course_var = tk.StringVar()
        self.attendance_var = tk.StringVar()

#Create a frame to hold the widgets
        self.frame = tk.Frame(self, bg="#ADD8E6")
        self.frame.pack(expand=True, fill=tk.BOTH)

#Labels and Entry widgets for lecture details
        tk.Label(self.frame, text="Lecture Name:", font = ('bold', 14), bg="#ADD8E6").grid(row=0, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.name_var).grid(row=0, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Lecture Surname:", font = ('bold', 14), bg="#ADD8E6").grid(row=1, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.surname_var).grid(row=1, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Course:", font = ('bold', 14), bg="#ADD8E6").grid(row=2, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.course_var).grid(row=2, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Students Attendance:", font = ('bold', 14), bg="#ADD8E6").grid(row=3, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.attendance_var).grid(row=3, column=1, padx=10, pady=5)

#Listbox to display lecture details
        self.listbox = Listbox(self.frame, width=70, height=10)
        self.listbox.grid(row=4, columnspan=2, padx=10, pady=5)

        scrollbar = Scrollbar(self.frame, orient="vertical")
        scrollbar.config(command=self.listbox.yview)
        scrollbar.grid(row=4, column=2, sticky="ns")

        self.listbox.config(yscrollcommand=scrollbar.set)

#Load existing students
        self.load_lecturers()

#Buttons for CRUD operations
        add_btn = tk.Button(self.frame, text="Add", font = 'bold', command=self.add_lecturer, bg="#FFB6C1")
        add_btn.grid(row=5, column=0, padx=10, pady=5)

        update_btn = tk.Button(self.frame, text="Update", font = 'bold', command=self.update_lecturer, bg="#FFB6C1")
        update_btn.grid(row=5, column=1, padx=10, pady=5)

        delete_btn = tk.Button(self.frame, text="Delete", font = 'bold', command=self.delete_lecturer, bg="#FFB6C1")
        delete_btn.grid(row=6, column=0, padx=10, pady=5)

        clear_btn = tk.Button(self.frame, text="Clear", font = 'bold', command=self.clear_lecturer_listbox, bg="#FFB6C1")
        clear_btn.grid(row=6, column=1, padx=10, pady=5)



    def clear_lecturer_listbox(self):
        # Delete all items from the listbox
        self.listbox.delete(0, tk.END)

    def add_lecturer(self):
        name = self.name_var.get()
        surname = self.surname_var.get()
        course = self.course_var.get()
        attendance = self.attendance_var.get()

        if name and surname and course and attendance:
            li.insert_lecturer(name, surname, course, attendance)
            self.listbox.insert(tk.END, f"{name} {surname}, {course}, {attendance}")
            self.clear_fields()
        else:
            messagebox.showwarning("Warning", "Please fill in all fields.")

    def load_lecturers(self):
        lecturers = lr.retrieve_lecturers()
        for lecturer in lecturers:
            self.listbox.insert(tk.END, f"{lecturer[1]} {lecturer[2]}, {lecturer[3]}, {lecturer[4]}")

    def update_lecturer(self):
        selected_index = self.listbox.curselection()
        if selected_index:
            selected_lecturer = self.listbox.get(selected_index)
            parts = selected_lecturer.split(", ")
            id = parts[-1]
            name = self.name_var.get()
            surname = self.surname_var.get()
            course = self.course_var.get()
            attendance = self.attendance_var.get()

            if name and surname and course and attendance:
                lu.update_lecturer(id, name, surname, course, attendance)
                self.listbox.delete(selected_index)
                self.listbox.insert(selected_index, f"{name} {surname}, {course}, {attendance}")
                self.clear_fields()
            else:
                messagebox.showwarning("Warning", "Please fill in all fields.")
        else:
            messagebox.showwarning("Warning", "Please select a lecturer to update.")

    def delete_lecturer(self):
        selected_index = self.listbox.curselection()
        if selected_index:
            selected_lecturer = self.listbox.get(selected_index)
            parts = selected_lecturer.split(", ")
            id = parts[-1]
            ld.delete_lecturer(id)
            self.listbox.delete(selected_index)
            self.clear_fields()
        else:
            messagebox.showwarning("Warning", "Please select a lecturer to delete.")

    def clear_fields(self):
        self.name_var.set("")
        self.surname_var.set("")
        self.course_var.set("")
        self.attendance_var.set("")

if __name__ == "__main__":
    root = tk.Tk()
    app = LecturerForm(root)
    root.mainloop()




